import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
import matplotlib.pyplot as plt
from flask import Flask, request, jsonify
from flask_cors import CORS  # Import the CORS module

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes
# Load the dataset
data = pd.read_csv("training_data.csv")
test_data = pd.read_csv("test_data.csv")
first_input = test_data.iloc[0].values

# Load the trained model
model = RandomForestClassifier(n_estimators=100, random_state=42)  # Example model initialization

# Assuming 'X' contains the symptoms/features and 'y' contains the target variable (diseases)
X = data.drop(columns=["prognosis"])
y = data["prognosis"]

# Handle missing values if any
imputer = SimpleImputer(strategy='most_frequent')
X_imputed = imputer.fit_transform(X)

# Train the model
model.fit(X_imputed, y)


@app.route('/predict', methods=['POST'])


def predict():
    try:
        # Get symptoms from the JSON request
        symptoms = request.json.get('symptoms')
        # print(symptoms)
        # Create a DataFrame with the symptoms
        input_df = pd.DataFrame([symptoms], columns=X.columns)
        print(input_df)
        # Handle missing values if any
        input_df_imputed = pd.DataFrame(imputer.transform(input_df), columns=input_df.columns)

        # Match symptoms with column names and fill 1 for corresponding columns
        input_symptom_encoded = pd.get_dummies(input_df_imputed).reindex(columns=X.columns, fill_value=0)

        # Make predictions
        predicted_probabilities = model.predict_proba(input_symptom_encoded)

        # Get the top 5 diseases with highest probabilities
        top_5_indices = predicted_probabilities.argsort()[0][-5:][::-1]
        top_5_diseases = model.classes_[top_5_indices]
        top_5_probabilities = predicted_probabilities[0][top_5_indices]
        print(top_5_probabilities)
        # Display the results
        plt.figure(figsize=(10, 6))
        plt.barh(top_5_diseases, top_5_probabilities, color='skyblue')
        plt.xlabel('Probability')
        plt.ylabel('Disease')
        plt.title('Top 5 Diseases with Highest Probabilities')
        plt.gca().invert_yaxis()  # Invert y-axis to display highest probability at the top
        plt.show()

        # Return the results as JSON
        result = {
            "top_diseases": list(top_5_diseases),
            "probabilities": list(top_5_probabilities)
        }

        return jsonify(result)

    except Exception as e:
        return jsonify({"error": str(e)})

if __name__ == '__main__':
    app.run(port=5000)

